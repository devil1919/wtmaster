package com.custom.pkg;

import javax.ejb.Local;

@Local
public interface SessionBeanLocal {

}


