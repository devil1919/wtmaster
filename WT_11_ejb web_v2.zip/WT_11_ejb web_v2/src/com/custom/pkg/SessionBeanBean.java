package com.custom.pkg;

import javax.ejb.Stateless;
import java.math.BigInteger;

@Stateless
public class SessionBeanBean implements SessionBeanRemote, SessionBeanLocal {
    @Override
    public String isPrime(int n) {
        final String notPrime = "isPrime(" + n + ") = false";
        final String isPrime = "isPrime(" + n + ") = true";
        if (n < 2) return notPrime;
        if (n < 4) return isPrime;

        if (n % 2 == 0) return notPrime;

        int sqrt = (int) (Math.sqrt(n));
        for (int i = 3; i <= sqrt; i += 2) {
            if (n % i == 0) return notPrime;
        }
        return isPrime;
    }

    @Override
    public String getFib(int n) {
        if (n < 1) return "Fib(" + n + ") = " + "Please enter a number n >= 1";
        StringBuilder result = new StringBuilder("Fib(" + n + ") = " + 1);
        if (n == 2) return result.toString();
        result.append(", 1");
        if(n==3) return result.toString();

        BigInteger a = BigInteger.valueOf(1), b = BigInteger.valueOf(1), c;
        for (int i = 3; i <= n; ++i) {
            c = a.add(b);
            a = b;
            b = c;
            result.append(", ").append(c);

        }
        return result.toString();
    }

    @Override
    public String getFact(int n) {
        BigInteger res = new BigInteger(String.valueOf(n), 10);
        for (int i = 2; i < n; ++i) res = res.multiply(new BigInteger(String.valueOf(i), 10));
        return "Factorial(" + n + ") = " + res.toString();
    }
}

