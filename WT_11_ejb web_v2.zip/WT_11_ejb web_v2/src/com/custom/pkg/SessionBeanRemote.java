package com.custom.pkg;

import javax.ejb.Remote;

@Remote
public interface SessionBeanRemote {

    String isPrime(int n);

    String getFib(int n);

    String getFact(int n);
}

