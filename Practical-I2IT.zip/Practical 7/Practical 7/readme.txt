First using xampp in phpmyadmin, create a database titled "ajax"
Then import the login.sql file from database folder into the phpmyadmin
Then run the file
Look out for the names in the table in phpmyadmin.
for your references the name are:- 
veera
vikas
vikasp
ganesh

The codes shows the output like this:-


Welcome :	veera
Account Created at :	2018-03-03 02:44:30


after you the enter name specified above 