<html>
 	<head>
 		<title>Employee Data</title>
 	</head>
 	<body>

	 <?php

		$servername = 'localhost';
		$usernameDB = 'username';
		$passwordDB = 'password';
		$dbName = 'database';

		$conn= new mysqli($servername, $usernameDB, $passwordDB, $dbName);
		if ($conn -> connect_error) {
			die("Connection Failed! " . mysqli_connect_error());
		}
		else {
			echo '<script language="javascript">';
			//echo 'alert("Database Connected Successfully!")';
			echo '</script>';
		}

		$query = "SELECT * FROM employeedata ORDER BY name ASC";
		$data = mysqli_query($conn, $query);
		echo "<h2><center>Employee Data</h2><p>";
		echo "<table border cellpadding=3>";
		echo "<tr><th width=100>Name</th><th width=100>Phone</th><th width=200>Email</th><th width=100 colspan=2>Admin</th></tr>";
		echo "<td colspan=5 align=right><a href=" .$_SERVER['PHP_SELF']. "?mode=add>Add Employee</a></td>";
		
		while($info = mysqli_fetch_array( $data ))
		{
			echo "<tr><td>".$info['name'] . "</td> ";
			echo "<td>".$info['phone'] . "</td> ";
			echo "<td> <a href=mailto:".$info['email'] . ">" .$info['email'] . "</a></td>";
			echo "<td><a href=" .$_SERVER['PHP_SELF']. "?id=" . $info['id'] ."&name=" . $info['name'] . "&phone=" . $info['phone'] ."&email=" . $info['email'] . "&mode=edit>Edit</a></td>";
			echo "<td><a href=" .$_SERVER['PHP_SELF']. "?id=" . $info['id'] ."&mode=remove>Remove</a></td></tr>";
		}
		echo "</table>";

		$mode = (isset($_GET['mode']) ? $_GET['mode'] : null);
		$name = (isset($_GET['name']) ? $_GET['name'] : null);
		$phone = (isset($_GET['phone']) ? $_GET['phone'] : null);
		$email = (isset($_GET['email']) ? $_GET['email'] : null);
		$id = (isset($_GET['id']) ? $_GET['id'] : null);
		$self = $_SERVER['PHP_SELF'];
		if ($mode=="add") {
			echo '<h2>Add Employee</h2>
			<p>
			<form action=';
			echo $self;
			echo '
			method=GET>
			<table>
			<tr><td>Name:</td><td><input type="text" name="name" /></td></tr>
			<tr><td>Phone:</td><td><input type="text" name="phone" /></td></tr>
			<tr><td>Email:</td><td><input type="text" name="email" /></td></tr>
			<tr><td colspan="2" align="center"><input type="submit" /></td></tr>
			<input type=hidden name=mode value=added>
			</table>
			</form>';
		}

		else if ($mode=="added") {
			$query = "INSERT INTO employeedata (name, phone, email) VALUES ('$name', '$phone', '$email')";
			mysqli_query($conn, $query);
			echo "<script>alert('Employee added!');</script>";

			$flag = 1;
		}

		else if ($mode=="edit") {
			echo '<h2>Edit Contact</h2>
			
			<form action=';
			echo $self;
			echo '
			method=GET>
			<table>
			<tr><td>Name:</td><td><input type="text" value="';
			echo $name;
			echo '" name="name" /></td></tr>
			<tr><td>Phone:</td><td><input type="text" value="';
			echo $phone;
			echo '" name="phone" /></td></tr>
			<tr><td>Email:</td><td><input type="text" value="';
			echo $email;
			echo '" name="email" /></td></tr>
			<tr><td colspan="2" align="center"><input type="submit" /></td></tr>
			<input type=hidden name=mode value=edited>
			<input type=hidden name=id value=';
			echo $id;
			echo '>
			</table>
			</form>';
		}

		else if ($mode=="edited") {
			$query = "UPDATE employeedata SET name = '$name', phone = '$phone', email = '$email' WHERE id = $id";
			mysqli_query($conn, $query);
			echo "<script>alert('Data Updated!');</script>";

			$flag = 1;
		}

		else if ($mode=="remove") {
			$query = "DELETE FROM employeedata where id=$id";
			mysqli_query($conn, $query);
			echo "<script>alert('Entry has been removed!');</script>";

			$flag = 1;
		}

		if ($flag == 1) {
			echo "<script>window.location.href = '/Employee.php';</script>";
		}

		$flag = 0;
	 ?>

 	</body>
 </html>
