import javax.ejb.Stateless;


@Stateless
public class SessionBeanBean implements SessionBeanRemote,SessionBeanLocal {

    public String getResult() {
        return "result returned";
    }
    public String getAddress() {
        return "address returned";
    }
    public String getCompanyName() {
        return "company name returned";
    }
}
