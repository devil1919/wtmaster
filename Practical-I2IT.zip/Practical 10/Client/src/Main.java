import javax.ejb.EJB;

public class Main {

    @EJB
    private static SessionBeanRemote sessionBeanBean = new SessionBeanBean();

    public static void main(String[] args) {
        System.out.println("=================================");
        System.out.println("Displaying Message using EJB:");
        System.out.println("=================================\n");

        System.out.println("Name of the Company is : " + sessionBeanBean.getCompanyName());
        System.out.println("Address of the Company is : " + sessionBeanBean.getAddress());
        System.out.println("Message is : " + sessionBeanBean.getResult());
    }
}

